﻿ỦNG HỘ CHANNEL BỌN MÌNH NHA: https://www.youtube.com/huychannel2


1. Chỗ này để đặt các file export được từ tiện ích http://cookie.atpsoftware.vn/
2. Chỉ cần export cookie từ facebook.com là được rồi!
3. Bạn có thể rename theo cách bạn thích hoặc dán vào file cookie.txt!


ỦNG HỘ CHANNEL BỌN MÌNH NHA: https://www.youtube.com/huychannel2