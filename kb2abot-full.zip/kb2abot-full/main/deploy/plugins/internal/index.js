const {getInstructor} = kb2abot.helpers;
const childs = [
	'autoreply',
	'plugman',
	'aar',
	'backup',
	'cprefix',
	'everyone',
	'game',
	'ducbo',
	'sexy',
	'covid',
	'help',
	'rank',
	'report',
	'version',
	'weather'
];

module.exports = {
	keywords: ['api1'],

	name: 'API 1 commands',

	description: 'Official api 1 commands',

	guide: '',

	childs,

	permission: {
		'*': '*'
	},

	datastoreDesign: {
		account: {
			global: {},
			local: {}
		},
		thread: {
			global: {},
			local: {}
		}
	},

	async onLoad() {},

	hookType: 'none',

	async onMessage(message, reply) {},

	async onCall(message, reply) {
		reply(getInstructor('API 1 ⭐', childs));
	}
};
