const axios = require("axios");

module.exports = {
	keywords: ['covid'],

	name: 'Covid 19',

	description: 'Lấy thông tin về tình hình dịch bệnh COVID-19',

	guide: '',

	childs: [],

	permission: {
		'*': '*'
	},

	datastoreDesign: {
		account: {
			global: {},
			local: {}
		},
		thread: {
			global: {},
			local: {}
		}
	},

	async onLoad() {},

	hookType: 'none',

	async onMessage(message, reply) {},

	async onCall(message, reply) {
			const {weather, main, name} = (
				await axios.get(
					`https://www.spermlord.ga/covid`
				)
			).data;
			const replyMsg = `'====== Thế Giới ======\n' +
		`😷 Nhiễm: ${data.thegioi.nhiem}\n` +
		`💚 Đã hồi phục: ${data.thegioi.hoiphuc}\n` +
		`💀 Tử vong: ${data.thegioi.tuvong}\n` +
		'====== Việt Nam ======\n' +
		`😷 Nhiễm: ${data.vietnam.nhiem}\n` +
		`💚 Đã hồi phục: ${data.vietnam.hoiphuc}\n` +
		`💀 Tử vong: ${data.vietnam.tuvong}\n` +
		`📰 Tin tức mới nhất: ${data.tintuc}\n` +
		`Dữ liệu được cập nhật vào: ${data.updatedAt}`,
		event.threadID, event.messageID`;
			reply(replyMsg);
		}
	};
