const {sendMessage} = kb2abot.helpers.fca;
const {getInstructor} = kb2abot.helpers;

const childs = [
	'gift',
	'goodnight',
	'hpbd',
	'kill',
	'kiss',
	'marry',
	'punch',
	'seophi',
	'shower',
	'sus'
];

module.exports = {
	keywords: ['api2'],

	name: 'api2',

	description: 'xã hội',

	guide: '',

	childs,

	permission: {
		'*': '*'
	},

	datastoreDesign: {
		account: {
			global: {},
			local: {}
		},
		thread: {
			global: {},
			local: {}
		}
	},

	async onLoad() {},

	hookType: 'none',

	async onMessage(message, reply) {},

	async onCall(message, reply) {
		reply(getInstructor('API 2 plugins', childs));
	}
};
