---
name: Plugin request
about: Describe the idea about your new plugin
title: ''
labels: plugin
assignees: ''

---

- Plugin name: 
- How's it work: 
- Why we should adding it:

Thanks.
